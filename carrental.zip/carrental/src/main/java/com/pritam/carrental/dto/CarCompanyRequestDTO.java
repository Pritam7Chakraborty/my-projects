// Request DTO
package com.pritam.carrental.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CarCompanyRequestDTO {
    private String name;
}
