package com.learningComponents.chat.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}
