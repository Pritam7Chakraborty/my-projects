package com.pritam.carrental.entity;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
