package com.pritam.carrental.entity;

public enum CarStatus {
    AVAILABLE,
    BOOKED,
    MAINTENANCE
}
