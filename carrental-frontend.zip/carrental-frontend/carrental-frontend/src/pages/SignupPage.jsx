function SignupPage() {
    return <div className="text-center text-xl mt-10">Signup Page</div>;
  }
  
  export default SignupPage;
  