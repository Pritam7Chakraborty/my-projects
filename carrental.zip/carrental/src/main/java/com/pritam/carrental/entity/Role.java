package com.pritam.carrental.entity;

public enum Role {
    ADMIN,
    CUSTOMER
}
