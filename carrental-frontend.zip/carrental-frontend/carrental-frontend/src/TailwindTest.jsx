export default function TailwindTest() {
    return (
      <div className="h-screen bg-red-500 flex justify-center items-center">
        <h1 className="text-6xl font-extrabold text-white">Tailwind ✅</h1>
      </div>
    );
  }
  